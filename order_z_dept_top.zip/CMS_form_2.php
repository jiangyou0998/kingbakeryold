<?php
     session_start();     
     if (!($_SESSION[authenticated])) {
       $_SESSION['status'] = 'neverLogin';
       header('Location: TaiHing.php');
     }

     require($DOCUMENT_ROOT . "connect.inc");

     if(isset($_POST[Submit]))
	 {
		
		
		$is_error = false;
		$error_mgs = '';
		
		include "fileupload.php";
		$uploadedfile_PDF = '';
		$uploadedfile_first = '';
		
		$up = new fileupload;
		$up -> set("path", "forms");
		$up -> set("maxsize", 20000000);
		$up -> set("allowtype", array("pdf",'xls','xlsx'));
		$up -> set("israndname", false);
		//顯示文檔
		if($up -> upload("uploadedfile")) 
		{
			
			$uploadedfile_PDF = $up->getFileName();
		} 
		else 
		{	
			$is_error  = true;
			$error_mgs = $up->getErrorMsg();
		}
		//原始文檔
		$up -> set("allowtype", array("pdf",'xls','doc','docx','xlsx'));
		if($up -> upload("uploadedfile_first")) 
		{
			$uploadedfile_first = $up->getFileName();
		} 
		else 
		{			
			//$is_error  = true;
			$error_mgs .= $up->getErrorMsg();
		}

        if(!$is_error ) 
	    {
			 $sql = "SELECT int_dept FROM tbl_user WHERE int_id = $_SESSION[user_id]";
			 $result = mysqli_query($con, $sql) or die($sql);
			 $record=mysqli_fetch_array($result);
			 $dept = $record[0];

			if ($_REQUEST[action] == 'new') 
			{
			   $sql = "INSERT INTO tbl_forms (txt_name, int_dept, txt_path, int_user, date_create, date_modify, date_delete, int_no,is_multi_print)";
			   $sql .= " VALUES ('";
			   $sql .= $_POST[txt_name];
			   $sql .= "','";
			   $sql .= $dept;
			   $sql .= "','";
			   $sql .= $uploadedfile_PDF;
			   $sql .= "','";
			   $sql .= $_SESSION['user_id'];
			   $sql .= "','";
			   $sql .= date("Y-m-d");
			   $sql .= "','";
			   $sql .= date("Y-m-d");
			   $sql .= "','";
			   $sql .= "2000-01-01";
			   $sql .= "','";
			   $sql .= $_POST[int_no];
			   $sql .= "','";
			   $sql .= $_POST[is_multi_print]?'1':'0';
			   $sql .= "')";
			   

			   $result = mysqli_query($con, $sql) or die($sql);
			   //echo "<script>alert(\"檔案 " . basename($_FILES['uploadedfile']['name']) . " 已成功上載\")</script>";
			   echo "<script>alert(\" 原始文檔 （" . $uploadedfile_first."） \\n\\n 顯示文檔（".$uploadedfile_PDF."）\\n\\n 已成功上載\")</script>";
			   echo "<script>document.location.href='CMS_form.php?type=$_REQUEST[type]';</script>";
			}
        }
	    else
	    {
			//echo "檔案 '" . basename($_FILES['uploadedfile']['name']) . "' 上傳發生錯誤";
			//if ($_FILES['uploadedfile']['error'] == 1) echo "<br>檔案大小限 2MB 以下";
			echo $error_mgs;
        }
     }
?>
<?php
if ($_REQUEST[action] == 'del') {
  $sql = "SELECT txt_path FROM tbl_forms WHERE int_id = $_REQUEST[id]";
  $result = mysqli_query($con, $sql) or die("invalid query");
  $record=mysqli_fetch_array($result);

  $myFile = "forms/" . basename($record[0]);
  unlink($myFile);

  $sql = "UPDATE tbl_forms SET date_delete = '" . date("Y-m-d") . "', int_user = $_SESSION[user_id] WHERE int_id = $_REQUEST[id]";
  $result = mysqli_query($con, $sql) or die("invalid query");
  echo "<script>document.location.href='CMS_form.php?type=$_REQUEST[type]';</script>";
}
else {
?>
<html>
<head>
<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=big5" />
<title>內聯網 - 後勤系統</title>
<script>

function check_sub()
{
	var file_name = document.getElementById("uploadedfile").value;
	if(changeType(file_name))
	{
		alert('顯示文檔只能為PDF,WORD或EXCEL文檔！');
		return false;
	}
}
function changeType(objFile) {

    var objtype=objFile.substring(objFile.lastIndexOf(".")).toLowerCase();

    var fileType=new Array('.pdf','.xls','.xlsx');

    for(var i=0; i<fileType.length; i++){
		
        if(objtype==fileType[i])

        {

             return false;

             break;

        }

    }

    return true;

}
</script>
</head>

<body>
<form enctype="multipart/form-data" action="" method="POST" name="upload" onSubmit="return check_sub()" id="upload">
主旨：<input name="txt_name" type="text" id="txt_name" size="30">
<br>
<br>
表格編號：
<input name="int_no" type="text" id="int_no" value="0" size="10">
<br>
<br>
大量列印：
<input name="is_multi_print" type="checkbox" id="is_multi_print" value="1">
<br>
<br>
選擇上傳之檔案（顯示文檔）　(建議格式：pdf)
<br>
<input name="uploadedfile" type="file" id="uploadedfile" accept="application/pdf,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" size="30" single />
<br>
<br>
<!--
選擇上傳之檔案（原始文檔）　(容許格式：doc, docx, xls, xlsx)
<br>
<input name="uploadedfile_first" type="file" size="30" />
<br>
-->
<br>
<input type="submit" name="Submit" value="提交" />
<input name="Back" type="button" id="Back" onClick="history.go(-1);" value="返回">
<input type="hidden" name="MAX_FILE_SIZE" value="20000000" />
</form>
</body>
</html>
<?php
}
?>