<?php 

	require($DOCUMENT_ROOT . "connect.inc");
	
	$info = $_POST["report_info"];
	var_dump($info);
	//die();
	$data = json_decode($info, true);
	var_dump($data);
	$item = join(', ', $data[item]);
	
	
	if($_POST[report_id] != ""){
		$report_id = $_POST[report_id];
	}else{
		$report_id = 'NULL';
	}

	
	if ($_POST["action"] == "update"){
		$sql = "DELETE FROM tbl_order_check WHERE int_id = $_POST[report_id]";
		mysqli_query($con, $sql) or die($sql);
	}
	$sql = "INSERT INTO tbl_order_check VALUES ";
	if($data[all_shop] == 1){
		$all_shop = 1;
		$sql .= "($report_id, '1', NULL, '$item', '$data[name]', '$data[num_of_day]', '$data[hide]', '$data[mainItem]', '$data[sort]')";
		
	}else{
		$all_shop = 0;
		
		if($all_th + $all_tw + $all_ctc + $all_other != 4){
			if(count($data[shop]) != 0){
				$shop = join(', ', $data[shop]);
				$sql .= "($report_id, '$all_shop ', '$shop', '$item', '$data[name]', '$data[num_of_day]', '$data[hide]', '$data[mainItem]', '$data[sort]', '$_POST[type]')";
			}else{
				$sql .= "($report_id, '$all_shop ',  NULL, '$item', '$data[name]', '$data[num_of_day]', '$data[separate]', '$data[hide]', '$data[mainItem]', '$data[sort]', '$_POST[type]')";
			}
		}else{
			$sql .= "($report_id, '$all_shop ', NULL, '$item', '$data[name]', '$data[num_of_day]', '$data[hide]', '$data[mainItem]', '$data[sort]', '$_POST[type]')";
		}
	}
	
	//die($sql);
	mysqli_query($con, $sql) or die($sql);
	header('Location: CMS_order_c_check_list.php');
	
	
?>