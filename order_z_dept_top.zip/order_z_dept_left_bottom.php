<!DOCTYPE html>
<html>
    <head>
	<style>
		*{ border:0px !important; }
	</style>
      <meta http-equiv="Content-Type" content="text/html; charset=big5" />
        <title></title>
    </head>
    <frameset rows="18%,*" noresize="noresize" frameborder="0" framespacing="0">
       <frame src="order_z_dept_middle.php" name="middleFrame" noresize="noresize" id="middleFrame" title="middleFrame" frameborder="0"/>
		<frame src="order_z_dept_bottom.php" name="mainFrame" id="mainFrame" title="mainFrame" frameborder="0"/>
    </frameset>
    <noframes></noframes>
</html>