<?php 
	require($DOCUMENT_ROOT . "connect.inc");
	$timestamp = gettimeofday("sec")+28800;

	if(isset($_POST["Sort"])){
		$sql = "UPDATE tbl_order_check SET int_sort = CASE int_id ";
		foreach($_POST as $id => $new_sort){
			if($id == "Sort") continue;
			if($new_sort == "") continue; 
			$sql .= "WHEN $id THEN $new_sort ";
		}
		$sql .= "ELSE int_sort END;";
		mysqli_query($con, $sql) or die($sql);
	}
	
	
	$aryOR = Array();
	$sql = "SELECT * FROM tbl_order_check order by int_sort, int_id";
	$result = mysqli_query($con, $sql) or die($sql);
	while($record  = mysqli_fetch_assoc($result)){
		$aryOR[] = $record;
	}
?>

<html>
<head>
	<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
	<meta http-equiv="Content-Type" content="text/html; charset=big5" />
	<title>內聯網</title>
	<script src="calendar/calendar.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/parser.js"></script>
	<script>
		function inputcheck(sender){
			
			if(sender.value.match(/\D/g)){
				sender.value = sender.value.replace(/\D/g, "");
			}
		}
	
	</script>
	<style>
		<!--
		.cssMenu { list-style-type: none; padding: 0; overflow: hidden; background-color: #ECECEC; float:right;}
		.cssMenuItem { float: right;  width:140px; border-right: 2px solid white; }
		.cssMenuItem a { display: block; color: black; text-align: center; padding: 4px; text-decoration: none; }
		.cssMenuItem a:hover { background-color: #BBBBBB; color:white; }
		
		.cssImportant{ background-color: #CCFFFF }
		
		div { margin-top:15px; }
		.cssTable1 { border-collapse: collapse;}
		.cssTable1 { border: 2px solid black;}
		.cssTable1 th{  padding:0px; text-align:center; border: 2px solid black; width:100px;}
		.cssTable1 td{  padding:0px; text-align:center; border: 2px solid black;}
		-->
	</style>
</head>
<body>
	<div align="center" width="100%">
	<div align="center" style="width:850px;">
		<h1>報告列表</h1>
		<form id="sort" method="POST" >
		<input type="hidden" name="Sort" value="1">
		<div style="margin-bottom:5px; text-align:right">
			<input type="submit" value="更新排序" style="cursor:pointer; position:relative; right:183px;">
			<img src="images/plus_2.png" onclick="document.location='CMS_order_c_check_add.php';" style="cursor:pointer; position:relative; right:0px;">
		</div>
		
		<table class="cssTable1" id="table1">
			<tr class="cssImportant">
				<th style="width:50px;">#</th>
				<th style="width:300px;">報告名稱</th>
				<th>相隔日數</th>
				<th>排序</th>
				<th>查看</th>
				<th>修改</th>
			</tr>
			
			<?php foreach($aryOR as $key => $value){ ?>
			<?php $s = Array('否', '是'); ?>
			<?php if($key % 2 == 0){ ?>
			<tr>
			<?php }else {?>
			<tr bgcolor="#DDDDDD">
			<?php } ?>
				<td><?=$key+1?></td>
				<td><?=$value[chr_report_name]?></td>
				<td><?=$value[int_num_of_day]?>日</td>
				<td><input value='<?=$value[int_sort]?>' style="width:50px; text-align:center" name="<?=$value[int_id]?>" oninput="inputcheck(this)" onpropertychange="inputcheck(this)"></td>
				<td><img src="images/clipboard.png" onclick="window.open('CMS_order_c_check_m.php?id=<?=$value[int_id]?>');" style="cursor:pointer;"></td>
				<td><img src="images/edit.png" onclick="document.location='CMS_order_c_check_add.php?id=<?=$value[int_id]?>&action=update';" style="cursor:pointer;"></td>
			</tr>
			<?php } ?>
			</form>
		</table>
	</div>
	</div>
</body>
</html>