<?php
     session_start();   

     if (!($_SESSION[authenticated])) {
       $_SESSION['status'] = 'neverLogin';
       $_SESSION[UrlRedirect] = 'order.php';
       header('Location: login.php');
     }
	 
	 require("connect.inc");
	 
     $timestamp = gettimeofday("sec");
	 $advDays = $_REQUEST[advDays];
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
<title>內聯網</title>
<script>
function opensupplier(aa){
	var Obj = document.getElementsByName("dept");
	var bool = false;
    for (var i = 0; i < Obj.length; i++){
		 if(Obj[i].checked==true){
			 bool=true;break;
		 }
	}
	if(bool){
		orderWindow = window.open("order_z_dept.php?dept="+Obj[i].value+"&advance="+aa,"orderWindow","height=768,width=1070,resizable=no,scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no, status=no");
		this.close();
	}else{
		alert("請先選擇部門");
	}
  
}
</script>
<style type="text/css">
<!--
body {
	background-color: #FFFFCC;
}
.style3 {
	font-size: medium
}
.style4 {color: #FF0000}
.style5 {
	font-size: medium;
	font-weight: bold;
}
-->
</style></head>

<body>

<?php
function isSunday($date)
{
	$isSun = false;
	
	if(date(D, $date) == "Sun")
		$isSun = true;
	
	return $isSun;
}

function showDayStr($dayCount, $selDate)
{
	$chiYearDay1 = "2015-02-19";		
	
	if(date('Y-m-d',$selDate)==$chiYearDay1) {
		$dayStr = "<font color=\"".(isSunday($selDate)?"Yellow":"Red")."\">年初一</font>";
	} else {
		switch($dayCount)
		{
			case 0:
				$dayStr = "明天";
				break;
			case 1:
				$dayStr = "後天";
				break;
			case 2:
				$dayStr = "大後天";
				break;
			case 3:
				$dayStr = "大大後天";
				break;
			case 4:
				$dayStr = "大大大後天";
				break;
			default:
				$dayStr = "特別安排";
				break;
		}
	}

	return $dayStr;
}

function showWkday($date)
{
	$rtnString = date('n月d日 (',$date);
	
	switch(date(D, $date))
	{
		case "Sun":
			$rtnString .= "日)";
			break;
		case "Mon":
			$rtnString .= "一)";
			break;
		case "Tue":
			$rtnString .= "二)";
			break;
		case "Wed":
			$rtnString .= "三)";
			break;
		case "Thu":
			$rtnString .= "四)";
			break;
		case "Fri":
			$rtnString .= "五)";
			break;
		default:
			$rtnString .= "六)";
			break;
	}
	
	return $rtnString;
}
?>

<center class="style5">
  請選<span class="style4">送貨日</span>及<span class="style4">部門</span>
  <br> 
  <input type="radio" name="dept" id="radio" value="R">烘焙
  <input type="radio" name="dept" id="radio" value="B">水吧
  <input type="radio" name="dept" id="radio" value="K">廚房
  <input type="radio" name="dept" id="radio" value="F">樓面
</center>
<table width="100%" border="1" align="center" cellpadding="3" cellspacing="0">
<?php
for($count=0;$count< $advDays;$count++)
{
	$selDate = $timestamp+86400*($count+1);
?>
  <tr <?php echo (isSunday($selDate)?"style=\"background-color:Red\"":"");?>>
    <td align="right"><strong><?=showDayStr($count, $selDate);?></strong></td>
    <td align="left"><a href="javascript:opensupplier(<?=$count;?>);"><strong><?=showWkday($selDate);?></strong></a></td>
  </tr>
<?php
}
?>
</table>
<br>
<center class="style3">不同送貨日<span class="style4">必須</span>分單</center>
</body>
</html>
