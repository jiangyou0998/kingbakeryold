<?php
  session_start();
  if (!($_SESSION[authenticated])) {
    $_SESSION['status'] = 'neverLogin';
    $_SESSION[UrlRedirect] = 'order_z_dept.php';
    header('Location: login.php');
  }
  require("connect.inc");
  $timestamp = gettimeofday("sec");

  $maxQTY = 300;
  $action = $_REQUEST[action];
  
  switch ($_SESSION['OrderDept']) {
    case "R":
	  $dept = "燒味";
	break;
	case "B":
	  $dept = "水吧";
	break;
	case "K":
	  $dept = "廚房";
	break;
	default:
	  $dept = "樓面";
	  $_SESSION['OrderDept'] = "F";
	break;
  }

  switch (date('N',$timestamp+86400*($_SESSION['advance']+1))) {
    case "1":
	  $week = "一";
	  break;
    case "2":
	  $week = "二";
	  break;
    case "3":
	  $week = "三";
	  break;
    case "4":
	  $week = "四";
	  break;
    case "5":
	  $week = "五";
	  break;
    case "6":
	  $week = "六";
	  break;
    case "7":
	  $week = "日";
	  break;
  }
  
  switch ($action) {
	case 'drop':
	  $sql_base = "SELECT int_base, int_min FROM tbl_order_z_menu WHERE int_id = '$_REQUEST[productid]'; ";
	  $result_base = mysqli_query($con, $sql_base) or die($sql_base);
	  $record_base = mysqli_fetch_row($result_base);
	  $base = $record_base[0];
	  $min = $record_base[1];
	  
	  $sql_check = "SELECT int_id AS orderID, int_qty FROM tbl_order_z_dept ";
      $sql_check .= "WHERE int_user = '$_SESSION[user_id]' AND int_product = '$_REQUEST[productid]' AND status = '0' AND chr_phase =  '$_SESSION[advance]' AND chr_dept = '$_SESSION[OrderDept]' ";

      $result_check = mysqli_query($con, $sql_check) or die($sql_check);
	  
      IF (($record_check = mysqli_fetch_row($result_check)) > 0) {
		  IF(($record_check[1] - $base) <= 0 || ($record_check[1] - $base) < $min) {
			  $sql = "DELETE FROM tbl_order_z_dept WHERE int_id = ".$record_check[0];
			  mysqli_query($con, $sql) or die($sql);
		}else{
			$newQty = $record_check[1] - $base;
			$sql  = "UPDATE tbl_order_z_dept SET int_qty_init = $newQty, int_qty = $newQty ";
			$sql .= "WHERE int_id = ".$record_check[0];
			mysqli_query($con, $sql) or die($sql);
		}
	  }
	  
	break;
    case 'add':
	  $sql_base = "SELECT int_base, int_min FROM tbl_order_z_menu WHERE int_id = '$_REQUEST[productid]'; ";
	  $result_base = mysqli_query($con, $sql_base) or die($sql_base);
	  $record_base = mysqli_fetch_row($result_base);
	  $base = $record_base[0];
	  $min = $record_base[1];
	  
	  
      $sql_check = "SELECT int_id AS orderID, int_qty FROM tbl_order_z_dept ";
      $sql_check .= "WHERE int_user = '$_SESSION[user_id]' AND int_product = '$_REQUEST[productid]' AND status = '0' AND chr_phase =  '$_SESSION[advance]' AND chr_dept = '$_SESSION[OrderDept]' ";

      $result_check = mysqli_query($con, $sql_check) or die($sql_check);
	  
      IF (($record_check = mysqli_fetch_row($result_check)) > 0) {
		  IF(($record_check[1] + $base) > $maxQTY) {
			  echo "<script>alert('每項目數量最多只可為「".$maxQTY."」');</script>";
		}
		
		
		
        $sql = "UPDATE tbl_order_z_dept SET int_qty_init = ".(($record_check[1] + $base) > $maxQTY ? $maxQTY." " : "int_qty + $base ").",int_qty = ".(($record_check[1] + $base) > $maxQTY ? $maxQTY." " : "int_qty + $base ");
        $sql .= "WHERE int_id = ".$record_check[0];
		
        mysqli_query($con, $sql) or die($sql);
      } ELSE {
        $sql = "INSERT INTO tbl_order_z_dept (order_date, int_user, int_product, int_qty, chr_ip, status, chr_phase, chr_dept, int_qty_init, insert_date) ";
        $sql .= "VALUES ('";
        $sql .= date('Y/n/j G:i:s',$timestamp);
        $sql .= "','";
        $sql .= $_SESSION[user_id];
        $sql .= "','";
        $sql .= $_REQUEST[productid];
        $sql .= "','";
        $sql .= $min;
        $sql .= "','";
        $sql .= $_SERVER['REMOTE_ADDR'];
        $sql .= "','";
        $sql .= 0;
        $sql .= "','";
        $sql .= $_SESSION['advance'];
		$sql .= "','";
		$sql .= $_SESSION['OrderDept'];
        $sql .= "', 1, NOW()) ";

        mysqli_query($con, $sql) or die($sql);
      }
    break;
    case 'DirectAdd':
		$moreThanMaxQTY = false;
      foreach ($_GET as $key=>$value) {
	    if (($value <> "") && ($key <> "Input_x") && ($key <> "Input_y") && ($key <> "Submit_x") && ($key <> "Submit_y") && ($key <> "action")){
		  if($_SESSION['chr_sap'] >= 'TH501' && $_SESSION['chr_sap'] <= 'TH599' && $value > $maxQTY){
			  $sql = "SELECT chr_sap FROM tbl_order_z_menu WHERE int_id = $key;";
			  $result = mysql_query($sql) or die($sql);
			  $record = mysql_fetch_row($result);
			  if ($record[0] == "RVG073-1")
				  $maxQTY = 900;
		  }
		  $sql_check = "SELECT int_id AS orderID, int_qty FROM tbl_order_z_dept ";
		  $sql_check .= "WHERE int_user = '$_SESSION[user_id]' AND int_product = '$key' AND status = '0' AND chr_phase =  '$_SESSION[advance]' AND chr_dept = '$_SESSION[OrderDept]' ";
	
		  $result_check = mysql_query($sql_check) or die($sql_check);
			IF (($record_check = mysql_fetch_row($result_check)) > 0) {
				IF(($record_check[1] + $value) > $maxQTY) {
					$moreThanMaxQTY = true;
				}
				
				$sql = "UPDATE tbl_order_z_dept SET int_qty_init = ".(($record_check[1] + $value) > $maxQTY ? $maxQTY." " : "int_qty + $value ")
						.", int_qty = ".(($record_check[1] + $value) > $maxQTY ? $maxQTY." " : "int_qty + $value ");
				$sql .= "WHERE int_id = ".$record_check[0];
/*				
			$sql = "UPDATE tbl_order_z_dept SET int_qty = int_qty + $value ";
			$sql .= "WHERE int_id = ".$record_check['orderID'];
*/
			mysql_query($sql) or die($sql);
			} ELSE {
				IF($value > $maxQTY) {
					$moreThanMaxQTY = true;
					$value = $maxQTY;
				}
				
			$sql = "INSERT INTO tbl_order_z_dept (order_date, int_user, int_product, int_qty, chr_ip, status, chr_phase, chr_dept, int_qty_init, insert_date) ";
			$sql .= "VALUES ('";
			$sql .= date('Y/n/j G:i:s',$timestamp);
			$sql .= "','";
			$sql .= $_SESSION[user_id];
			$sql .= "','";
			$sql .= $key;
			$sql .= "','";
			$sql .= $value;
			$sql .= "','";
			$sql .= $_SERVER['REMOTE_ADDR'];
			$sql .= "','";
			$sql .= 0;
			$sql .= "','";
			$sql .= $_SESSION['advance'];
			$sql .= "','";
			$sql .= $_SESSION['OrderDept'];
			$sql .= "', '$value', NOW()) ";

			mysql_query($sql) or die($sql);
		  }
		}
      }

	  if($moreThanMaxQTY) echo "<script>alert('每項目數量最多只可為「".$maxQTY."」');</script>";
	  
    break;
    case 'delete':
	  $sql = "UPDATE tbl_order_z_dept SET status = 4, order_date = NOW() WHERE int_id = $_REQUEST[id] ";
      mysqli_query($con, $sql) or die($sql);
	  
    break;
    case 'update':
		$sql_base = "SELECT int_base, int_min, int_qty FROM tbl_order_z_dept T0 
		LEFT JOIN tbl_order_z_menu T1 ON T0.int_product = T1.int_id WHERE T0.int_id = '$_REQUEST[int_id]'; ";
	    $result_base = mysqli_query($con, $sql_base) or die($sql_base);
	    $record_base = mysqli_fetch_row($result_base);
	    $base = $record_base[0];
	    $min = $record_base[1];
		$oqty = $record_base[2];
		
	    if($_SESSION['chr_sap'] >= 'TH501' && $_SESSION['chr_sap'] <= 'TH599' && $_REQUEST[int_qty] > $maxQTY){
			$sql = "
			SELECT T1.chr_sap 
			FROM tbl_order_z_dept T0 
				LEFT JOIN tbl_order_z_menu T1 ON T0.int_product = T1.int_id
			WHERE T0.int_id = $_REQUEST[int_id];";
			$result = mysqli_query($con, $sql) or die($sql);
			$record = mysql_fetch_row($result);
			if ($record[0] == "RVG073-1")
				$maxQTY = 900;
		}
		
		IF($_REQUEST[int_qty] > $maxQTY) {
			$qty = $maxQTY;
			echo "<script>alert('每項目數量最多只可為「".$maxQTY."」');</script>";
		} ELSE {
			$qty = $_REQUEST[int_qty];
		}
		
		IF($_REQUEST[int_qty] % $base != 0) {
			$qty = $oqty;
			echo "<script>alert('該項目數量必須以「".$base."」為單位');</script>";
		}else IF($_REQUEST[int_qty] < $min) {
			$qty = $oqty;
			echo "<script>alert('該項目最少落單數量為「".$min."」');</script>";
		}
		
        $sql = "UPDATE tbl_order_z_dept SET int_qty_init = $qty, int_qty = $qty ";
        $sql .= "WHERE int_id = $_REQUEST[int_id] ";
        mysqli_query($con, $sql) or die($sql);
    break;
  }

?>
<html>
<head>
<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=big5" />
<title>內聯網</title>
</head>

<body>
<form action="order_z_dept_2.php?action=confirm&dept=<?=$dept?>" method="post" id="cart" name="cart" target="_top">
<div align="right"><strong><font color="#FF0000" size="+3">部門：<?=$dept?><br>送貨日期：<?=date('n月d日 (',$timestamp+86400*($_SESSION['advance']+1)).$week.")";?></font></strong></div>
<table width="100%" height="89%" border="1" cellpadding="10" cellspacing="2">
  <tr>
    <td valign="top"><table width="100%" border="0" cellspacing="2" cellpadding="2">
<?php
  $sql = "
	SELECT 
		tbl_order_z_dept.int_id AS orderID,
		tbl_order_z_menu.chr_name AS itemName,
		tbl_order_z_menu.chr_no,
		tbl_order_z_unit.chr_name AS UoM,
		tbl_order_z_menu.chr_cuttime,
		tbl_order_z_dept.int_qty,
		tbl_order_z_dept.status,
		tbl_order_z_menu.int_phase,
		LEFT(tbl_order_z_cat.chr_name, 2) AS suppName
	FROM
		tbl_order_z_dept
			INNER JOIN tbl_order_z_menu ON tbl_order_z_dept.int_product = tbl_order_z_menu.int_id
			INNER JOIN tbl_order_z_unit ON tbl_order_z_menu.int_unit = tbl_order_z_unit.int_id
			INNER JOIN tbl_order_z_group ON tbl_order_z_menu.int_group = tbl_order_z_group.int_id
			INNER JOIN tbl_order_z_cat ON tbl_order_z_group.int_cat = tbl_order_z_cat.int_id
	WHERE
		tbl_order_z_dept.int_user = '$_SESSION[user_id]'
			AND tbl_order_z_dept.status IN (0 , 1)
			AND tbl_order_z_dept.int_qty > 0
			AND tbl_order_z_dept.chr_phase = '$_SESSION[advance]'
			AND tbl_order_z_dept.chr_dept = '$_SESSION[OrderDept]'
			AND tbl_order_z_menu.int_id
	ORDER BY tbl_order_z_dept.order_date DESC , 
			 tbl_order_z_group.int_cat , 
			 tbl_order_z_group.int_sort;";

  $result = mysqli_query($con, $sql) or die($sql);
  $count = 0;
  $haveoutdate = 0;
  WHILE($record = mysqli_fetch_array($result)) {
    if ($count & 1) {
      $bg = "#F0F0F0";
    } else {
      $bg = "#FFFFFF";
    }
    $count += 1;
?>
      <tr bgcolor="<?php echo $bg;?>">
        <td width="10" align="right"><?=$count;?>.</td>
        <td><font color="blue" size=-1><?=$record['suppName'];?> </font><?="$record[itemName], $record[chr_no]";?></td>
        <td align="center">
        <?php
          if ($record['status'] == 1) echo "<font color=blue size=-1>(已落)</font>";
		  if($record[int_phase]-1 == $_SESSION[advance] && $record[chr_cuttime] <= date('Hi',$timestamp)){
		//if (date('Hi',$timestamp) > $record['chr_cuttime']) {
			  echo "<img src='images/alert.gif' width='20' height='20'>";
			  $haveoutdate = 1;
		  }
          
        ?>        
		</td>
        <td width="100" align="center">x 
          <input name="<?=$record['orderID'];?>" type="text" value="<?=round($record['int_qty'],2);?>" size="3" maxlength="4" onChange="document.location.href='?action=update&int_id='+this.name+'&int_qty='+this.value"></td>
        <td align="center"><?=$record[3];?></td>
        <td align="center">
			<?php if ($record['status'] == 0){?>
				<a href="?action=delete&id=<?=$record[0];?>&advance=<?=$_REQUEST['advance'];?>"><font color="#FF6600">X</font></a>
			<?php }else{ ?>
				&nbsp;
			<?php } ?>
		</td>
      </tr>
<?php
  }
?>
      <tr>
        <td colspan="6">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3" valign="middle">分店：<?=$_SESSION[user]?><br>柯打日期：<?=date('Y/n/j',$timestamp)?><br>柯打合共：<?=$count;?></td>
        <td colspan="3" align="center"><input name="Input" type="image" src="images/Finish.jpg" border="0" onClick="cart.submit();"></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>