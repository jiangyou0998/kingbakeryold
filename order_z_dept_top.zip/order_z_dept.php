<?php
     session_start();     
     if (!($_SESSION[authenticated])) {
       $_SESSION['status'] = 'neverLogin';
       $_SESSION[UrlRedirect] = 'order_z_dept.php';
       header('Location: login.php');
     }
  $_SESSION['OrderDept'] = $_REQUEST['dept'];
  $_SESSION['advance'] = $_REQUEST['advance']+0;
?>
<html>
<head>
<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=big5" />
<title>內聯網</title>
</head>
<frameset rows="*" cols="43%,*" frameborder="no" border="1" framespacing="0">
	<frame src="order_z_dept_left.php" name="leftFrame" scrolling="Yes" noresize="noresize" id="leftFrame" title="leftFrame" />
	<frame src="order_z_dept_top.php" name="topFrame" scrolling="Yes" noresize="noresize" id="topFrame" title="topFrame" />
</frameset>
</html>
