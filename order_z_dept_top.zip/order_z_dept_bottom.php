<?php
     session_start();     
     if (!($_SESSION[authenticated])) {
       $_SESSION['status'] = 'neverLogin';
       $_SESSION[UrlRedirect] = 'order_z_dept.php';
       header('Location: login.php');
    }
	require($DOCUMENT_ROOT . "connect.inc");
	$timestamp = gettimeofday("sec");
	$curtime = date('Hi',$timestamp);
	//echo $curtime;
	//echo $_SESSION['advance'];
	
	/*
	 $stop_date = new DateTime();
	 $advance = $_SESSION['advance'];
	 echo 'date before day adding: ' . $stop_date->format('Y-m-d') . "<br>"; 
	 $count = 0;
	 while($count<=$advance){
		$stop_date->modify('+1 day');
		echo 'date after adding 1 day: ' . $stop_date->format('Y-m-d') . "<br>";
		$count++;
	 }
	*/
	 
?>
<html>
<head>
<META name="ROBOTS" content="NOINDEX,NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=big5" />
<title>內聯網</title>
<style type="text/css">
input.item {
	font-size: 12px;
}
.div {width:100%;height:100%;overflow:auto;overflow-x:hidden;}
body {
	margin:0;
}
.ss { color:blue; }
.item {color:black !important; }

</style>
<script>
	function addItem(id){
		console.log(window.frames);
		
	}
	function dropItem(id){
		alert(id);
	}
</script>
</head>

<body style="overflow-y:hidden" bgcolor="#697caf" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" topmargin="0">
<hr>

<div class="div">
<form name="orderByFi" action="order_z_dept_left.php" target="leftFrame" method="get">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="39"></td>
    <td align="left">&nbsp;

    </td>
    <td width="50" align="center" bgcolor="#00356B">現貨</td>
    <td width="50" align="center" bgcolor="#D7710D">新貨</td>
    <td width="50" align="center" bgcolor="#008081">季節貨</td>
    <td width="50" align="center" bgcolor="#7D0101">已截單</td>
    <td width="50" align="center" bgcolor="#666666">暫停</td>
  </tr>
</table>
<form name="orderByDirect" action="order_z_dept_left.php" target="leftFrame" method="get">
<br/>
<br/>
<input type="hidden" name="action" value="DirectAdd">
<table border="0" cellpadding="0" cellspacing="5">
  <tr>
<?php
  $sql  = "
  SELECT 
    T0.int_id AS itemID,
    T0.chr_name AS itemName,
    T0.chr_no,
    T1.chr_name AS UoM,
    T0.status,
    T0.txt_detail_1,
    T0.txt_detail_2,
    T0.txt_detail_3,
    T0.chr_image,
	T0.int_phase,
	T0.chr_cuttime
  FROM
    tbl_order_z_menu T0
        INNER JOIN tbl_order_z_unit T1 ON T1.int_id = T0.int_unit
        LEFT JOIN tbl_order_z_menu_v_shop T2 ON T2.int_menu_id = T0.int_id
  WHERE
    T0.int_group = '$_REQUEST[groupid]'
        AND T0.status <> 4
		AND T2.int_user_id  = '$_SESSION[user_id]'
		AND T0.int_phase-1 <= '$_SESSION[advance]'
  GROUP BY T0.int_id
  ORDER BY T0.int_sort, T0.int_id";
  //
  if($_SESSION[type] == 3){
	$sql  = "
	  SELECT 
		T0.int_id AS itemID,
		T0.chr_name AS itemName,
		T0.chr_no,
		T1.chr_name AS UoM,
		T0.status,
		T0.txt_detail_1,
		T0.txt_detail_2,
		T0.txt_detail_3,
		T0.chr_image,
		T0.chr_cuttime
	  FROM
		tbl_order_z_menu T0
			INNER JOIN tbl_order_z_unit T1 ON T1.int_id = T0.int_unit
	  WHERE
		T0.int_group = '$_REQUEST[groupid]'
			AND T0.status <> 4
	  GROUP BY T0.int_id
	  ORDER BY T0.int_sort, T0.int_id";
  }
  //die($sql);
  $result = mysqli_query($con, $sql) or die();
  $count = 1;
  $countdisplay = 1;
  WHILE($record = mysqli_fetch_array($result)) {
	//echo $record['chr_cuttime'];
	
	$styleTD = "background-color:#FFFF00; ";
	$styleFont = "color: black; ";
	$disableButton = "";
	if($record[chr_cuttime] <= $curtime){
		$overTime = true;
		$record['status'] = 999;
		$styleTD = "background-color:#7D0101; color:white; ";
		$styleFont = "color: white;";
		$disableButton = "disabled";
	}
    
?>

    <td width="150" height="60" align="center" style="<?=$styleTD?>">
	<table width="150px" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2" align="center" style="font-size:16px;">
		<?php IF ($record['status'] <> 2 && $record['status'] <> 999) {?>
		<a id="itm-<?=$record[itemID]?>" target="leftFrame" href="order_z_dept_left.php?action=add&productid=<?=$record['itemID'];?>" style="<?=$styleFont?>">
		<?php }else { ?>
		<a style="<?=$styleFont?>">
		<?php } ?>
		
		 <table class="item" width="100%">
			<tr>
				<td colspan="4" align="left" style="font-size:12px; <?=$styleFont?>">
					<?= $record[chr_no];?>
				</td>
			</tr>
			<tr>
				<td colspan="4" align="center" style="font-size:16px;">
					<span style="<?=$styleFont?>"><?=$record['itemName'];?></span>
				</td>
			</tr>
			<tr>
				<td style="height:20px; width:50%; font-size:24px; text-align:center" colspan="2">
					<a id="itm-<?=$record[itemID]?>" target="leftFrame" href="order_z_dept_left.php?action=add&productid=<?=$record['itemID'];?>">
						<button type="button" style="height:100%; width:100%; font-size:18px;" <?=$disableButton?>>+</button>
					</a>
				</td>
				<td style="height:20px; width:50%; text-align:center" colspan="2">
					<a id="itm-<?=$record[itemID]?>" target="leftFrame" href="order_z_dept_left.php?action=drop&productid=<?=$record['itemID'];?>" style="color:black;">
						<button type="button" style="height:100%; width:100%; font-size:18px;" <?=$disableButton?>>-</button>
					</a>
				</td>
			</tr>
		 </table>
		 </a>
        </td>
      </tr>
    </table>
	</td>
<?php
	$count++;
	if($count >= 4){
		echo "</tr><tr>";
		$count = 1;
	}
  }
?>
  </tr>
</table>
</div>
</form>
</body>
</html>
